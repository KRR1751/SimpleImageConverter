﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenImageFromToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.oif1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oif2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oif3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.OpenImageToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteImageFromClipboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadURLImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ConvertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyLoadedImageToClipboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyLoadedImagepathToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.FullViewWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.AlwaysShowPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HowToUseItToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.TSSL = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.OpenImageInTargetPathToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyImagePathToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyFileLocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 69)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Open Image"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.Location = New System.Drawing.Point(190, 69)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Convert!"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"PNG", "JPEG (JPG)", "GIF", "BMP", "TIFF", "EMF", "ICO", "WMF", "EXIF"})
        Me.ComboBox1.Location = New System.Drawing.Point(93, 70)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(91, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Select an Image to convert!"
        '
        'PictureBox1
        '
        Me.PictureBox1.ImageLocation = ""
        Me.PictureBox1.Location = New System.Drawing.Point(279, 40)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(292, 252)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.InitialDirectory = "%userprofile%\Pictures"
        Me.SaveFileDialog1.RestoreDirectory = True
        Me.SaveFileDialog1.Title = "Pick a directory to Save your new Image"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "All supported Image files (*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tiff;*.emf;*.ico;*.wm" &
    "f;*.exif)|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tiff;*.emf;*.ico;*.wmf;*.exif|All fil" &
    "es (*.*)|*.*"
        Me.OpenFileDialog1.InitialDirectory = "%userprofile%\Pictures"
        Me.OpenFileDialog1.RestoreDirectory = True
        Me.OpenFileDialog1.Title = "Open an Image that will be converted"
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(220, 141)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(45, 22)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Load"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(276, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Preview:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.OptionsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(274, 24)
        Me.MenuStrip1.TabIndex = 7
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenImageFromToolStripMenuItem, Me.ToolStripSeparator2, Me.OpenImageToolStripMenuItem1, Me.PasteImageFromClipboardToolStripMenuItem, Me.LoadURLImageToolStripMenuItem, Me.ToolStripSeparator3, Me.ConvertToolStripMenuItem, Me.ToolStripSeparator5, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenImageFromToolStripMenuItem
        '
        Me.OpenImageFromToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.oif1, Me.oif2, Me.oif3})
        Me.OpenImageFromToolStripMenuItem.Name = "OpenImageFromToolStripMenuItem"
        Me.OpenImageFromToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.OpenImageFromToolStripMenuItem.Text = "Open Image from:"
        '
        'oif1
        '
        Me.oif1.Name = "oif1"
        Me.oif1.Size = New System.Drawing.Size(126, 22)
        Me.oif1.Text = "File"
        '
        'oif2
        '
        Me.oif2.Name = "oif2"
        Me.oif2.Size = New System.Drawing.Size(126, 22)
        Me.oif2.Text = "Clipboard"
        '
        'oif3
        '
        Me.oif3.Name = "oif3"
        Me.oif3.Size = New System.Drawing.Size(126, 22)
        Me.oif3.Text = "URL"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(219, 6)
        '
        'OpenImageToolStripMenuItem1
        '
        Me.OpenImageToolStripMenuItem1.Name = "OpenImageToolStripMenuItem1"
        Me.OpenImageToolStripMenuItem1.Size = New System.Drawing.Size(222, 22)
        Me.OpenImageToolStripMenuItem1.Text = "Open Image"
        '
        'PasteImageFromClipboardToolStripMenuItem
        '
        Me.PasteImageFromClipboardToolStripMenuItem.Name = "PasteImageFromClipboardToolStripMenuItem"
        Me.PasteImageFromClipboardToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.PasteImageFromClipboardToolStripMenuItem.Text = "Paste Image from Clipboard"
        '
        'LoadURLImageToolStripMenuItem
        '
        Me.LoadURLImageToolStripMenuItem.Name = "LoadURLImageToolStripMenuItem"
        Me.LoadURLImageToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.LoadURLImageToolStripMenuItem.Text = "Load URL Image"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(219, 6)
        '
        'ConvertToolStripMenuItem
        '
        Me.ConvertToolStripMenuItem.Name = "ConvertToolStripMenuItem"
        Me.ConvertToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.ConvertToolStripMenuItem.Text = "Convert"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(219, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeyDisplayString = "Alt+F4"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyLoadedImageToClipboardToolStripMenuItem, Me.CopyLoadedImagepathToolStripMenuItem, Me.ToolStripSeparator4, Me.FullViewWindowToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'CopyLoadedImageToClipboardToolStripMenuItem
        '
        Me.CopyLoadedImageToClipboardToolStripMenuItem.Name = "CopyLoadedImageToClipboardToolStripMenuItem"
        Me.CopyLoadedImageToClipboardToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.CopyLoadedImageToClipboardToolStripMenuItem.Text = "Copy loaded Image"
        '
        'CopyLoadedImagepathToolStripMenuItem
        '
        Me.CopyLoadedImagepathToolStripMenuItem.Name = "CopyLoadedImagepathToolStripMenuItem"
        Me.CopyLoadedImagepathToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.CopyLoadedImagepathToolStripMenuItem.Text = "Copy loaded Image (path)"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(209, 6)
        '
        'FullViewWindowToolStripMenuItem
        '
        Me.FullViewWindowToolStripMenuItem.Name = "FullViewWindowToolStripMenuItem"
        Me.FullViewWindowToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.FullViewWindowToolStripMenuItem.Text = "Full view Window"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowPreviewToolStripMenuItem, Me.ToolStripSeparator6, Me.AlwaysShowPreviewToolStripMenuItem})
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.OptionsToolStripMenuItem.Text = "Options"
        '
        'ShowPreviewToolStripMenuItem
        '
        Me.ShowPreviewToolStripMenuItem.CheckOnClick = True
        Me.ShowPreviewToolStripMenuItem.Name = "ShowPreviewToolStripMenuItem"
        Me.ShowPreviewToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ShowPreviewToolStripMenuItem.Text = "Show Preview"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(183, 6)
        '
        'AlwaysShowPreviewToolStripMenuItem
        '
        Me.AlwaysShowPreviewToolStripMenuItem.Checked = True
        Me.AlwaysShowPreviewToolStripMenuItem.CheckOnClick = True
        Me.AlwaysShowPreviewToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.AlwaysShowPreviewToolStripMenuItem.Name = "AlwaysShowPreviewToolStripMenuItem"
        Me.AlwaysShowPreviewToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.AlwaysShowPreviewToolStripMenuItem.Text = "Always show Preview"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HowToUseItToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'HowToUseItToolStripMenuItem
        '
        Me.HowToUseItToolStripMenuItem.Name = "HowToUseItToolStripMenuItem"
        Me.HowToUseItToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.HowToUseItToolStripMenuItem.Text = "How to use it"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(144, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'ComboBox2
        '
        Me.ComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(12, 44)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(253, 21)
        Me.ComboBox2.TabIndex = 8
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSSL})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 169)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(274, 22)
        Me.StatusStrip1.TabIndex = 9
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'TSSL
        '
        Me.TSSL.Name = "TSSL"
        Me.TSSL.Size = New System.Drawing.Size(42, 17)
        Me.TSSL.Text = "Ready!"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenImageInTargetPathToolStripMenuItem, Me.OpenImageToolStripMenuItem, Me.ToolStripSeparator1, Me.CopyImagePathToolStripMenuItem, Me.CopyFileLocationToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(214, 98)
        '
        'OpenImageInTargetPathToolStripMenuItem
        '
        Me.OpenImageInTargetPathToolStripMenuItem.Name = "OpenImageInTargetPathToolStripMenuItem"
        Me.OpenImageInTargetPathToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.OpenImageInTargetPathToolStripMenuItem.Text = "Open image in target path"
        Me.OpenImageInTargetPathToolStripMenuItem.Visible = False
        '
        'OpenImageToolStripMenuItem
        '
        Me.OpenImageToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.OpenImageToolStripMenuItem.Name = "OpenImageToolStripMenuItem"
        Me.OpenImageToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.OpenImageToolStripMenuItem.Text = "Open image"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(210, 6)
        '
        'CopyImagePathToolStripMenuItem
        '
        Me.CopyImagePathToolStripMenuItem.Name = "CopyImagePathToolStripMenuItem"
        Me.CopyImagePathToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.CopyImagePathToolStripMenuItem.Text = "Copy image path"
        '
        'CopyFileLocationToolStripMenuItem
        '
        Me.CopyFileLocationToolStripMenuItem.Name = "CopyFileLocationToolStripMenuItem"
        Me.CopyFileLocationToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.CopyFileLocationToolStripMenuItem.Text = "Copy image full path"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(12, 94)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(233, 13)
        Me.LinkLabel1.TabIndex = 11
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Clipboard Image detected! Click here to paste it!"
        Me.LinkLabel1.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "From:"
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"File", "Clipboard", "Web"})
        Me.ComboBox3.Location = New System.Drawing.Point(43, 116)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(122, 21)
        Me.ComboBox3.TabIndex = 13
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(171, 118)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(94, 17)
        Me.CheckBox1.TabIndex = 14
        Me.CheckBox1.Text = "Show Preview"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(43, 143)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(171, 20)
        Me.TextBox1.TabIndex = 15
        Me.TextBox1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 192)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(253, 100)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Preview Options"
        '
        'Label5
        '
        Me.Label5.Enabled = False
        Me.Label5.Location = New System.Drawing.Point(6, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(241, 54)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "This ""view Window"" will show up the full image in its full resolution as a native" &
    " window. The window is temporary and if you want to get rid of it, just simply c" &
    "lose it."
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(72, 19)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(110, 23)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Full view Window"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "URL:"
        Me.Label4.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(274, 191)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(600, 365)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(290, 230)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Simple Image Converter"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents HowToUseItToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents TSSL As ToolStripStatusLabel
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label3 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents OpenImageInTargetPathToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenImageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents CopyFileLocationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button4 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents CopyImagePathToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenImageToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PasteImageFromClipboardToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents LoadURLImageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ConvertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyLoadedImageToClipboardToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyLoadedImagepathToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AlwaysShowPreviewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents FullViewWindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenImageFromToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents oif1 As ToolStripMenuItem
    Friend WithEvents oif2 As ToolStripMenuItem
    Friend WithEvents oif3 As ToolStripMenuItem
    Friend WithEvents ShowPreviewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
End Class
