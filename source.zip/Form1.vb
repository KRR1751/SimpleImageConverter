﻿Imports System.ComponentModel
Imports System.Net

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Check for Command Args

        If Not My.Application.CommandLineArgs.Count = 0 Then
            If IO.File.Exists(My.Application.CommandLineArgs(0)) Then
                Dim filePath As String = My.Application.CommandLineArgs(0)
                Try
                    If filePath.StartsWith("""") AndAlso filePath.EndsWith("""") Then
                        filePath = filePath.Trim(""""c, """"c)
                    End If

                    ComboBox2.Text = filePath
                    SetImageAndResize(filePath)
                    TSSL.Text = "Ready!"
                Catch ex As Exception
                    TSSL.Text = "Failed to open image: """ & ex.Message & """"
                End Try
            End If
        End If


        ' Registry

        If My.Computer.Registry.CurrentUser.OpenSubKey("Software\SafrelyProduction\ImageConverter") Is Nothing Then
            My.Computer.Registry.CurrentUser.CreateSubKey("Software\SafrelyProduction\ImageConverter")
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\SafrelyProduction\ImageConverter", "AlwaysShowPreview", "0", Microsoft.Win32.RegistryValueKind.DWord)
        Else
            AlwaysShowPreviewToolStripMenuItem.Checked = My.Computer.Registry.GetValue("HKEY_CURRENT_USER\Software\SafrelyProduction\ImageConverter", "AlwaysShowPreview", False)
        End If

        ' Main

        ComboBox1.Items.Clear()

        For Each i As String In InternalNames
            If i.Length > 0 Then
                ' Remove the first letter
                Dim resultString As String = i.Substring(1)
                ComboBox1.Items.Add(resultString.ToUpper)
            End If
        Next

        ComboBox1.SelectedIndex = 0
        ComboBox3.SelectedIndex = 0

        ' Options

        CheckBox1.Checked = AlwaysShowPreviewToolStripMenuItem.Checked
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click, ConvertToolStripMenuItem.Click
        Try
            SaveFileDialog1.Filter = ComboBox1.SelectedItem & " |*" & InternalNames(ComboBox1.SelectedIndex)
            If SaveFileDialog1.ShowDialog() = DialogResult.OK Then

                If ComboBox1.SelectedItem = "PNG" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Png)

                ElseIf ComboBox1.SelectedItem = "JPG" OrElse ComboBox1.SelectedItem = "JPEG" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg)

                ElseIf ComboBox1.SelectedItem = "GIF" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Gif)

                ElseIf ComboBox1.SelectedItem = "BMP" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Bmp)

                ElseIf ComboBox1.SelectedItem = "TIFF" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Tiff)

                ElseIf ComboBox1.SelectedItem = "EMF" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Emf)

                ElseIf ComboBox1.SelectedItem = "ICO" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Icon)

                ElseIf ComboBox1.SelectedItem = "WMF" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Wmf)

                ElseIf ComboBox1.SelectedItem = "EXIF" Then
                    PictureBox1.Image.Save(SaveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Exif)

                End If

                TSSL.Text = "Convertion was successful! (Click here to do more actions)"
                TSSL.ToolTipText = SaveFileDialog1.FileName
                ContextMenuStrip1.Tag = SaveFileDialog1.FileName
            End If
        Catch ex As Exception
            TSSL.Text = "Failed to convert image: """ & ex.Message & """"
            TSSL.ToolTipText = ""
        End Try
    End Sub
    Dim defPictureHeight As Integer = 252
    Dim MaxWidth As Integer = 292
    Private Sub SetImageAndResize(ByVal imagePath As String)
        Dim img As Image = Image.FromFile(imagePath)

        If img.Height > defPictureHeight Then
            Dim aspectRatio As Double = img.Width / img.Height
            Dim newWidth As Integer = CInt(PictureBox1.Height * aspectRatio)

            If newWidth > MaxWidth Then
                newWidth = MaxWidth
            End If

            PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
            PictureBox1.Width = newWidth
        Else
            PictureBox1.SizeMode = PictureBoxSizeMode.AutoSize
        End If

        PictureBox1.Image = img
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click, OpenImageToolStripMenuItem1.Click
        Try
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                ComboBox2.Text = OpenFileDialog1.FileName
                SetImageAndResize(OpenFileDialog1.FileName)
                TSSL.Text = "Ready!"
            End If
        Catch ex As Exception
            TSSL.Text = "Failed to open image: """ & ex.Message & """"
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click, LoadURLImageToolStripMenuItem.Click
        Try
            SetImageFromUrl(TextBox1.Text)
        Catch ex As Exception
            MsgBox("Error, " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Dim validImage As Boolean = False
    Public Sub CheckIfValidImage()
        Select Case ComboBox3.SelectedIndex
            Case 0
                Select Case validImage
                    Case True
                        Button2.Enabled = True
                        SetImageAndResize(ComboBox2.Text)
                    Case False
                        Button2.Enabled = False
                        PictureBox1.Image = Nothing
                End Select
            Case 1
                Button2.Enabled = False
                PictureBox1.Image = Nothing

                If Clipboard.ContainsImage = True Then
                    LinkLabel1.Visible = True
                    TSSL.Text = "Ready!"
                Else
                    LinkLabel1.Visible = False
                    TSSL.Text = "Cannot detect any Image in your Clipboard."
                End If
            Case 2
                Button2.Enabled = False
                PictureBox1.Image = Nothing

                If Not TextBox1.Text = "" Then
                    Button3.Enabled = True
                    TSSL.Text = "Ready!"
                Else
                    Button3.Enabled = False
                    TSSL.Text = "Error, invalid URL!"
                End If
        End Select

    End Sub

    Private Sub ComboBox2_TextChanged(sender As Object, e As EventArgs) Handles ComboBox2.TextChanged
        If ComboBox3.SelectedIndex = 0 Then
            If IO.File.Exists(ComboBox2.Text) = True Then
                Dim II As New IO.FileInfo(ComboBox2.Text)
                If IsExtensionSupported(II.Extension) = True Then
                    validImage = True
                    CheckIfValidImage()
                Else
                    validImage = False
                    CheckIfValidImage()
                End If
            Else
                validImage = False
                CheckIfValidImage()
            End If
        End If
    End Sub

    Private Sub SetImageFromUrl(ByVal imageUrl As String)
        Using client As New WebClient()
            Dim imgData As Byte() = client.DownloadData(imageUrl)

            Using ms As New IO.MemoryStream(imgData)
                Dim img As Image = Image.FromStream(ms)

                If img.Height > defPictureHeight Then
                    Dim aspectRatio As Double = img.Width / img.Height
                    Dim newWidth As Integer = CInt(PictureBox1.Height * aspectRatio)

                    If newWidth > MaxWidth Then
                        newWidth = MaxWidth
                    End If

                    PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
                    PictureBox1.Width = newWidth
                Else
                    PictureBox1.SizeMode = PictureBoxSizeMode.AutoSize
                End If

                PictureBox1.Image = img
            End Using
        End Using
    End Sub

    Public InternalNames As New List(Of String) From {
                ".png",
                ".jpg",
                ".jpeg",
                ".gif",
                ".bmp",
                ".tiff",
                ".emf",
                ".ico",
                ".wmf",
                ".exif"
            }

    Function IsExtensionSupported(extension As String) As Boolean
        Dim lowerCaseExtension As String = extension.ToLower()

        If InternalNames.Contains(lowerCaseExtension) Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub HowToUseItToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HowToUseItToolStripMenuItem.Click
        MsgBox("Instructions:

  1. Press Open Image to find the image you want to convert.
  2. Click on the drop-down box to select what format you want to convert it to.
  3. Press convert!", MsgBoxStyle.Information, "How to use Simple Image Converter")
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        If ComboBox3.SelectedIndex = 0 Then
            If IO.File.Exists(ComboBox2.Text) = True Then
                Dim II As New IO.FileInfo(ComboBox2.Text)
                If IsExtensionSupported(II.Extension) = True Then
                    validImage = True
                    CheckIfValidImage()
                Else
                    validImage = False
                    CheckIfValidImage()
                End If
            Else
                validImage = False
                CheckIfValidImage()
            End If

            ComboBox2.Enabled = True
            Button1.Enabled = True

            Label4.Visible = False
            TextBox1.Visible = False
            Button3.Visible = False

            LinkLabel1.Visible = False
            TSSL.Text = "Ready!"
        ElseIf ComboBox3.SelectedIndex = 1 Then
            ComboBox2.Enabled = False
            Button1.Enabled = False

            Label4.Visible = False
            TextBox1.Visible = False
            Button3.Visible = False

            CheckIfValidImage()
        ElseIf ComboBox3.SelectedIndex = 2 Then
            ComboBox2.Enabled = False
            Button1.Enabled = False

            Label4.Visible = True
            TextBox1.Visible = True
            Button3.Visible = True

            LinkLabel1.Visible = False
            CheckIfValidImage()
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            Me.Size = New Size(600, 365)
        Else
            Me.Size = New Size(290, 230)
        End If
    End Sub

    Private Sub PictureBox1_LoadCompleted(sender As Object, e As AsyncCompletedEventArgs) Handles PictureBox1.LoadCompleted
        Select Case ComboBox3.SelectedIndex
            Case 1
                Button2.Enabled = True
            Case 2
                Button2.Enabled = True
        End Select
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked, PasteImageFromClipboardToolStripMenuItem.Click
        PictureBox1.Image = Clipboard.GetImage
        LinkLabel1.Visible = False
        Button2.Enabled = True
    End Sub

    Private Sub Form1_Activated(sender As Object, e As EventArgs) Handles Me.Activated, Me.GotFocus
        If ComboBox3.SelectedIndex = 1 Then
            If Clipboard.ContainsImage = True Then
                LinkLabel1.Visible = True
                TSSL.Text = "Ready!"
            Else
                LinkLabel1.Visible = False
                TSSL.Text = "Cannot detect any Image in your Clipboard."
            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If Not TextBox1.Text = "" Then
            Button3.Enabled = True
            TSSL.Text = "Ready!"
        Else
            Button3.Enabled = False
            TSSL.Text = "Error, invalid URL!"
        End If
    End Sub

    Private Sub TSSL_Click(sender As Object, e As EventArgs) Handles TSSL.Click
        If TSSL.Text = "Convertion was successful! (Click here to do more actions)" Then
            ContextMenuStrip1.Show(MousePosition)
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click, FullViewWindowToolStripMenuItem.Click
        If PictureBox1.Image IsNot Nothing Then
            Dim tempForm As New Form
            tempForm.BackgroundImage = PictureBox1.Image
            tempForm.BackgroundImageLayout = ImageLayout.None
            tempForm.Text = "Image"
            tempForm.Size = tempForm.BackgroundImage.Size
            tempForm.ShowIcon = False

            tempForm.Show()
        Else
            MsgBox("There is no Image selected to view it in a Temporary form.", MsgBoxStyle.Exclamation, "No Image loaded")
        End If
    End Sub

    Private Sub CopyFileLocationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyFileLocationToolStripMenuItem.Click
        Clipboard.SetText(ContextMenuStrip1.Tag.ToString)
    End Sub

    Private Sub OpenImageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenImageToolStripMenuItem.Click
        Try
            Dim PSI As New ProcessStartInfo(ContextMenuStrip1.Tag)
            PSI.UseShellExecute = True
            Process.Start(True)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub OpenImageInTargetPathToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenImageInTargetPathToolStripMenuItem.Click
        Try
            Dim II As New IO.FileInfo(ContextMenuStrip1.Tag)
            Dim PSI As New ProcessStartInfo("%windir%\explorer.exe", II.DirectoryName)
            PSI.UseShellExecute = True
            Process.Start(True)
        Catch ex As Exception
            MsgBox(ex.Message & " """ & ContextMenuStrip1.Tag & """", MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub CopyImagePathToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyImagePathToolStripMenuItem.Click
        Dim II As New IO.FileInfo(ContextMenuStrip1.Tag)
        Clipboard.SetText(II.DirectoryName)
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.ShowDialog(Me)
    End Sub

    Private Sub FileToolStripMenuItem_DropDownOpening(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.DropDownOpening
        OpenImageToolStripMenuItem1.Enabled = Button1.Enabled
        PasteImageFromClipboardToolStripMenuItem.Enabled = LinkLabel1.Visible

        If Button3.Visible = False Then
            LoadURLImageToolStripMenuItem.Enabled = False
        Else
            LoadURLImageToolStripMenuItem.Enabled = Button3.Enabled
        End If

        ConvertToolStripMenuItem.Enabled = Button2.Enabled
    End Sub

    Private Sub OpenImageFromToolStripMenuItem_DropDownOpening(sender As Object, e As EventArgs) Handles OpenImageFromToolStripMenuItem.DropDownOpening
        Select Case ComboBox3.SelectedIndex
            Case 0
                oif1.CheckState = CheckState.Indeterminate
                oif2.CheckState = CheckState.Unchecked
                oif3.CheckState = CheckState.Unchecked
            Case 1
                oif1.CheckState = CheckState.Unchecked
                oif2.CheckState = CheckState.Indeterminate
                oif3.CheckState = CheckState.Unchecked
            Case 2
                oif1.CheckState = CheckState.Unchecked
                oif2.CheckState = CheckState.Unchecked
                oif3.CheckState = CheckState.Indeterminate
        End Select
    End Sub

    Private Sub OptionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OptionsToolStripMenuItem.Click
        ShowPreviewToolStripMenuItem.Checked = CheckBox1.Checked
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub CopyLoadedImageToClipboardToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyLoadedImageToClipboardToolStripMenuItem.Click
        If PictureBox1.Image IsNot Nothing Then
            Clipboard.SetImage(PictureBox1.Image)
        Else
            MsgBox("There is no Image selected to copy it into the Clipboard.", MsgBoxStyle.Exclamation, "No Image loaded")
        End If
    End Sub

    Private Sub EditToolStripMenuItem_DropDownOpening(sender As Object, e As EventArgs) Handles EditToolStripMenuItem.DropDownOpening
        If ComboBox3.SelectedIndex = 0 Then
            If IO.File.Exists(ComboBox2.Text) = True Then
                Dim II As New IO.FileInfo(ComboBox2.Text)
                If IsExtensionSupported(II.Extension) = True Then
                    CopyLoadedImagepathToolStripMenuItem.Enabled = True
                Else
                    CopyLoadedImagepathToolStripMenuItem.Enabled = False
                End If
            Else
                CopyLoadedImagepathToolStripMenuItem.Enabled = False
            End If
        End If
    End Sub

    Private Sub CopyLoadedImagepathToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyLoadedImagepathToolStripMenuItem.Click
        Clipboard.SetText(ComboBox2.Text)
    End Sub

    Private Sub oif1_Click(sender As Object, e As EventArgs) Handles oif1.Click
        ComboBox3.SelectedIndex = 0
    End Sub

    Private Sub oif2_Click(sender As Object, e As EventArgs) Handles oif2.Click
        ComboBox3.SelectedIndex = 1
    End Sub

    Private Sub oif3_Click(sender As Object, e As EventArgs) Handles oif3.Click
        ComboBox3.SelectedIndex = 2
    End Sub

    Private Sub ShowPreviewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowPreviewToolStripMenuItem.Click
        CheckBox1.Checked = ShowPreviewToolStripMenuItem.Checked
    End Sub

    Private Sub AlwaysShowPreviewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AlwaysShowPreviewToolStripMenuItem.Click
        My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\SafrelyProduction\ImageConverter", "AlwaysShowPreview", AlwaysShowPreviewToolStripMenuItem.Checked, Microsoft.Win32.RegistryValueKind.DWord)
    End Sub
End Class
